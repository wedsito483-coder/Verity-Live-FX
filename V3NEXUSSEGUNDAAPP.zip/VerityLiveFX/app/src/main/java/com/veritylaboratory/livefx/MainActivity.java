package com.veritylaboratory.livefx;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.content.SharedPreferences;
import android.os.Build;
import android.speech.RecognizerIntent;
import android.util.Base64;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/** VERITY LIVE FX v3: la página de efectos dentro de un WebView, con cámara, micrófono y guardado de grabaciones. */
public class MainActivity extends Activity {
    private static final int REQ_PERMS = 5001;
    private static final int REQ_FILE = 5002;
    private static final int REQ_MIC = 5003;
    private static final int REQ_VOICE = 5004;
    private static final String[] HOSTS = {"api.groq.com", "api.anthropic.com", "generativelanguage.googleapis.com", "api.openai.com"};

    private String micLang = "es-MX";
    private boolean immersive = false;
    private final Speaker.Done doneCb = new Speaker.Done() { @Override public void onDone() { runJs("window.nxTtsDone&&window.nxTtsDone()"); } };
    private final Mic.Sink sink = new Mic.Sink() { @Override public void js(String c) { runJs(c); } };

    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private PermissionRequest pendingRequest;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        webView = new WebView(this);
        webView.setBackgroundColor(0xFF080A12);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setSupportMultipleWindows(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        webView.addJavascriptInterface(new Bridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(new Runnable() {
                    @Override public void run() { handlePermission(request); }
                });
            }

            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                boolean img = false;
                try {
                    String[] acc = params.getAcceptTypes();
                    if (acc != null) for (String a : acc) if (a != null && a.startsWith("image")) img = true;
                } catch (Exception ignored) {}
                i.setType(img ? "image/*" : "audio/*");
                if (img) i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                try {
                    startActivityForResult(Intent.createChooser(i, img ? "Elige imágenes de fondo" : "Elige una canción"), REQ_FILE);
                } catch (Exception e) {
                    fileCallback = null;
                    callback.onReceiveValue(null);
                    Toast.makeText(MainActivity.this, "No se pudo abrir el selector de archivos.", Toast.LENGTH_LONG).show();
                }
                return true;
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
    }

    /** Pide los permisos de Android que necesite la página (cámara y/o micrófono) y luego se los concede. */
    private void handlePermission(PermissionRequest request) {
        List<String> need = new ArrayList<String>();
        for (String r : request.getResources()) {
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r) && !has(Manifest.permission.CAMERA)) need.add(Manifest.permission.CAMERA);
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r) && !has(Manifest.permission.RECORD_AUDIO)) need.add(Manifest.permission.RECORD_AUDIO);
        }
        if (need.isEmpty()) { grant(request); return; }
        if (pendingRequest != null) { try { pendingRequest.deny(); } catch (Exception ignored) {} }
        pendingRequest = request;
        requestPermissions(need.toArray(new String[0]), REQ_PERMS);
    }

    private boolean has(String p) { return checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED; }

    private void grant(PermissionRequest request) {
        List<String> ok = new ArrayList<String>();
        for (String r : request.getResources()) {
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r) && has(Manifest.permission.CAMERA)) ok.add(r);
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r) && has(Manifest.permission.RECORD_AUDIO)) ok.add(r);
        }
        if (ok.isEmpty()) request.deny(); else request.grant(ok.toArray(new String[0]));
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == REQ_MIC) {
            if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) runJs("window.nxMicGranted&&window.nxMicGranted()");
            else runJs("window.nxMicError&&window.nxMicError(9)");
            return;
        }
        if (code != REQ_PERMS || pendingRequest == null) return;
        PermissionRequest r = pendingRequest;
        pendingRequest = null;
        grant(r);
    }

    @Override
    protected void onActivityResult(int code, int result, Intent data) {
        super.onActivityResult(code, result, data);
        if (code == REQ_VOICE) {
            String txt = "";
            if (result == RESULT_OK && data != null) {
                java.util.ArrayList<String> l = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                if (l != null && !l.isEmpty()) txt = l.get(0);
            }
            if (txt.trim().length() > 0) runJs("window.nxMicResult&&window.nxMicResult(" + JSONObject.quote(txt) + ")");
            else runJs("window.nxMicError&&window.nxMicError(7)");
            return;
        }
        if (code != REQ_FILE || fileCallback == null) return;
        Uri[] out = null;
        if (result == RESULT_OK && data != null) {
            if (data.getClipData() != null) {
                int n = data.getClipData().getItemCount();
                out = new Uri[n];
                for (int k = 0; k < n; k++) out[k] = data.getClipData().getItemAt(k).getUri();
            } else if (data.getData() != null) out = new Uri[]{data.getData()};
        }
        fileCallback.onReceiveValue(out);
        fileCallback = null;
    }

    @Override
    public void onBackPressed() {
        if (webView == null) { super.onBackPressed(); return; }
        webView.evaluateJavascript("(function(){try{return window.vfxBack?window.vfxBack():false}catch(e){return false}})()", new ValueCallback<String>() {
            @Override public void onReceiveValue(String v) {
                if (!"true".equals(v)) MainActivity.super.onBackPressed();
            }
        });
    }

    @Override
    protected void onStop() {
        Mic.cancel();
        Speaker.stop();
        runJs("window.nxPause&&window.nxPause()");
        super.onStop();
    }

    @Override
    protected void onResume() {
        super.onResume();
        applyImmersive();
        runJs("window.nxResume&&window.nxResume()");
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) applyImmersive();
    }

    @Override
    protected void onDestroy() {
        Mic.cancel();
        Speaker.stop();
        if (webView != null) { webView.destroy(); webView = null; }
        super.onDestroy();
    }

    void runJs(final String js) {
        runOnUiThread(new Runnable() {
            @Override public void run() {
                try { if (webView != null) webView.evaluateJavascript(js, null); } catch (Exception ignored) {}
            }
        });
    }

    /** Pantalla completa de verdad: sin barra de estado ni de navegación y cubriendo la muesca de la cámara. */
    @SuppressWarnings("deprecation")
    private void applyImmersive() {
        try {
            Window w = getWindow();
            if (immersive) {
                if (Build.VERSION.SDK_INT >= 28) {
                    WindowManager.LayoutParams lp = w.getAttributes();
                    lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
                    w.setAttributes(lp);
                }
                if (Build.VERSION.SDK_INT >= 30) {
                    w.setDecorFitsSystemWindows(false);
                    WindowInsetsController c = w.getInsetsController();
                    if (c != null) {
                        c.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                        c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                    }
                } else {
                    w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
                }
            } else {
                if (Build.VERSION.SDK_INT >= 30) {
                    w.setDecorFitsSystemWindows(true);
                    WindowInsetsController c = w.getInsetsController();
                    if (c != null) c.show(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                } else {
                    w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
                }
            }
        } catch (Exception ignored) {}
    }

    private boolean hostOk(String url) {
        try {
            URL u = new URL(url);
            if (!"https".equals(u.getProtocol())) return false;
            for (String h : HOSTS) if (h.equals(u.getHost())) return true;
        } catch (Exception ignored) {}
        return false;
    }

    /** Guarda la grabación en la carpeta Descargas (sin pedir permisos de almacenamiento). */
    private final class Bridge {
        @JavascriptInterface
        public void immersive(final boolean on) {
            runOnUiThread(new Runnable() { @Override public void run() { immersive = on; applyImmersive(); } });
        }

        @JavascriptInterface
        public void toBackground() {
            runOnUiThread(new Runnable() { @Override public void run() { moveTaskToBack(true); } });
        }

        @JavascriptInterface
        public String nxGet(String key) {
            try { return getSharedPreferences("vfx", MODE_PRIVATE).getString("k_" + key, ""); } catch (Exception e) { return ""; }
        }

        @JavascriptInterface
        public void nxSet(String key, String val) {
            try {
                SharedPreferences.Editor ed = getSharedPreferences("vfx", MODE_PRIVATE).edit();
                if (val == null || val.length() == 0) ed.remove("k_" + key); else ed.putString("k_" + key, val);
                ed.apply();
            } catch (Exception ignored) {}
        }

        /** Petición HTTPS a las APIs de IA (se hace aquí, no en la página, para evitar bloqueos de CORS). Responde con window.nxHttp(id, estado, texto). */
        @JavascriptInterface
        public void httpPost(final String id, final String url, final String headersJson, final String body) {
            if (id == null || !id.matches("[A-Za-z0-9_]{1,40}")) return;
            if (!hostOk(url)) { runJs("window.nxHttp&&window.nxHttp('" + id + "',0," + JSONObject.quote("Dirección no permitida") + ")"); return; }
            new Thread(new Runnable() {
                @Override public void run() {
                    int status = 0; String text;
                    HttpURLConnection c = null;
                    try {
                        c = (HttpURLConnection) new URL(url).openConnection();
                        c.setRequestMethod("POST");
                        c.setConnectTimeout(15000);
                        c.setReadTimeout(60000);
                        c.setDoOutput(true);
                        JSONObject h = new JSONObject(headersJson == null ? "{}" : headersJson);
                        java.util.Iterator<String> it = h.keys();
                        while (it.hasNext()) { String k = it.next(); c.setRequestProperty(k, h.getString(k)); }
                        byte[] bytes = (body == null ? "" : body).getBytes("UTF-8");
                        OutputStream os = c.getOutputStream();
                        os.write(bytes); os.flush(); os.close();
                        status = c.getResponseCode();
                        InputStream in = status >= 400 ? c.getErrorStream() : c.getInputStream();
                        ByteArrayOutputStream bo = new ByteArrayOutputStream();
                        if (in != null) {
                            byte[] buf = new byte[8192]; int n;
                            while ((n = in.read(buf)) > 0) { bo.write(buf, 0, n); if (bo.size() > 2000000) break; }
                            in.close();
                        }
                        text = bo.toString("UTF-8");
                    } catch (Exception e) {
                        status = 0; text = String.valueOf(e.getMessage());
                    } finally { if (c != null) c.disconnect(); }
                    runJs("window.nxHttp&&window.nxHttp('" + id + "'," + status + "," + JSONObject.quote(text) + ")");
                }
            }).start();
        }

        @JavascriptInterface
        public String micStart(final boolean fast) {
            if (!Mic.hasPermission(MainActivity.this)) {
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        try { requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC); } catch (Exception ignored) {}
                    }
                });
                return "perm";
            }
            final boolean g = Mic.googleAvailable(MainActivity.this);
            runOnUiThread(new Runnable() { @Override public void run() { Mic.start(MainActivity.this, sink, micLang, fast); } });
            return g ? "ok" : "nogoogle";
        }

        @JavascriptInterface
        public void micCancel() {
            runOnUiThread(new Runnable() { @Override public void run() { Mic.cancel(); } });
        }

        @JavascriptInterface
        public boolean googleOk() { return Mic.googleAvailable(MainActivity.this); }

        /** Respaldo: la ventanita de voz de Google. */
        @JavascriptInterface
        public String micDialog() {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    try {
                        Mic.cancel();
                        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, micLang);
                        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Habla ahora…");
                        startActivityForResult(i, REQ_VOICE);
                    } catch (Exception e) {
                        runJs("window.nxMicError&&window.nxMicError(-1)");
                    }
                }
            });
            return "ok";
        }

        @JavascriptInterface
        public void ttsSpeak(final String text) { Speaker.speak(MainActivity.this, text, doneCb); }

        @JavascriptInterface
        public void voiceConfig(String lang, String voice, String rate, String pitch) {
            if (lang != null && lang.length() > 0) micLang = lang;
            Speaker.configure(lang, voice, rate, pitch);
        }

        @JavascriptInterface
        public String ttsLangOk(String lang) { return Speaker.langStatus(MainActivity.this, lang); }

        @JavascriptInterface
        public void ttsStop() { Speaker.stop(); }

        @JavascriptInterface
        public boolean saveFile(String name, String mime, String base64) {
            try {
                String safe = name == null ? "verity-live-fx.webm" : name.replaceAll("[^A-Za-z0-9._-]", "_");
                if (safe.length() == 0) safe = "verity-live-fx.webm";
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, safe);
                v.put(MediaStore.MediaColumns.MIME_TYPE, mime == null || mime.length() == 0 ? "video/webm" : mime);
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                v.put(MediaStore.MediaColumns.IS_PENDING, 1);
                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (uri == null) return false;
                OutputStream os = getContentResolver().openOutputStream(uri, "w");
                if (os == null) { getContentResolver().delete(uri, null, null); return false; }
                os.write(Base64.decode(base64, Base64.DEFAULT));
                os.flush();
                os.close();
                ContentValues done = new ContentValues();
                done.put(MediaStore.MediaColumns.IS_PENDING, 0);
                getContentResolver().update(uri, done, null, null);
                runOnUiThread(new Runnable() {
                    @Override public void run() { Toast.makeText(MainActivity.this, "Grabación guardada en Descargas", Toast.LENGTH_SHORT).show(); }
                });
                return true;
            } catch (Exception e) {
                return false;
            }
        }
    }
}
